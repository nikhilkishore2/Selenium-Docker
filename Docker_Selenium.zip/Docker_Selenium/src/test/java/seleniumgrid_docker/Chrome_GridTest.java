package seleniumgrid_docker;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class Chrome_GridTest {
	WebDriver driver;
	@Test()
	public void chromegritest() throws MalformedURLException{
		DesiredCapabilities ds=DesiredCapabilities.chrome();


		URL url=new URL ("http://192.168.99.100:4444/wd/hub");

		RemoteWebDriver rd=new RemoteWebDriver(url,ds);
		rd.get("https://google.com");
		System.out.println("Chrome Browser Session page title are :"+ rd.getTitle() );
		rd.quit();

	}
}
