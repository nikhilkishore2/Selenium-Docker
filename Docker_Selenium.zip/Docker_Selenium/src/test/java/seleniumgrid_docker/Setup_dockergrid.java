package seleniumgrid_docker;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class Setup_dockergrid {

	@BeforeTest
	public void startdockerfile() throws IOException, InterruptedException{

		Runtime.getRuntime().exec("cmd /c start start_docker.bat");
		Thread.sleep(32000);
	}

	@AfterTest
	public void stopdockerfile() throws IOException, InterruptedException{

		Runtime.getRuntime().exec("cmd /c start stop_docker.bat");
		Thread.sleep(6000);
		Runtime.getRuntime().exec("taskkill /f /im cmd.exe");
	}
}
