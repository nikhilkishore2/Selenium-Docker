package seleniumgrid_docker;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class Firefox_GridTest {
	@Test()
	public void firefoxgritest() throws MalformedURLException{
		DesiredCapabilities ds=DesiredCapabilities.firefox();


		URL url=new URL ("http://192.168.99.100:4444/wd/hub");

		RemoteWebDriver rd=new RemoteWebDriver(url,ds);
		rd.get("https://google.com");
		System.out.println("Firefox Browser Session page title are :"+ rd.getTitle() );
		rd.quit();

	}
}
